package com.example.mjucampusguide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BtnActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_btn);


    }
}