package com.example.mjucampusguide;public class Bilding {
}
